package com.example.agcmuno

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.agcmuno.ui.theme.AGCMUNOTheme

object Routes {
    const val HOME   = "home"
    const val NAMES  = "names"
    const val SENSOR = "sensor"
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AGCMUNOTheme {
                val navController = rememberNavController()
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    NavHost(
                        navController = navController,
                        startDestination = Routes.HOME,
                        modifier = Modifier.padding(innerPadding)
                    ) {
                        composable(Routes.HOME) {
                            HomeScreen(
                                onNavigateToNames  = { navController.navigate(Routes.NAMES) },
                                onNavigateToSensor = { navController.navigate(Routes.SENSOR) }
                            )
                        }
                        composable(Routes.NAMES) {
                            NameListScreen(onBack = { navController.popBackStack() })
                        }
                        composable(Routes.SENSOR) {
                            SensorScreen(onBack = { navController.popBackStack() })
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HomeScreen(
    onNavigateToNames: () -> Unit,
    onNavigateToSensor: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF7F7FD))
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("AGCMUNO", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = Color(0xFF4B5E91))
        Text("Laboratorio 3", fontSize = 16.sp, color = Color.Gray)

        Spacer(modifier = Modifier.height(56.dp))

        Button(
            onClick = onNavigateToNames,
            modifier = Modifier.fillMaxWidth().height(56.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4B5E91)),
            shape = RoundedCornerShape(50)
        ) {
            Text("📋  Ver Listado de Nombres", fontSize = 16.sp, color = Color.White)
        }

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = onNavigateToSensor,
            modifier = Modifier.fillMaxWidth().height(56.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE91E63)),
            shape = RoundedCornerShape(50)
        ) {
            Text("📡  Ver Sensor del Dispositivo", fontSize = 16.sp, color = Color.White)
        }
    }
}
